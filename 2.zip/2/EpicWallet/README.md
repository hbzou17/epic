# Epic Wallet

This is the reference implementation of [Epic's](https://gitlab.com/epiccash/epic) wallet. It consists of 2 major pieces:

* The Epic Wallet APIs, which are intended for use by Epic community wallet developers. The wallet APIs can be directly linked into other projects or invoked via a JSON-RPC interface.

* A reference command-line wallet, which provides a baseline wallet for Epic and demonstrates how the wallet APIs should be called.

## Usage

To build and try out the Epic Wallet, see the [build docs](doc/build.md).

To get the Epic Wallet as a .deb package, see [Running the test net](https://gitlab.com/epiccash/epic/blob/master/doc/running.org).

## License

Apache License v2.0
