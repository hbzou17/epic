#!/bin/sh

cd /opt/epic-miner-opencl
exec ./bin/epic-miner
