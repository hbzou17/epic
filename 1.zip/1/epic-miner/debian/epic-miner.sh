#!/bin/sh

cd /opt/epic-miner
exec ./bin/epic-miner
